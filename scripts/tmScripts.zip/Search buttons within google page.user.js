// ==UserScript==
// @name          Search buttons within google page
// @include       /https?:\/\/(www\.)?google\.(com|(?:com?\.)?\w\w)\/.*/
// @description   Adds a Youtube search link: Web, Images, Videos, Youtube, News, Maps, Shopping, ...
// @version       1.1.1a
// @author        wOxxOm
// @namespace     wOxxOm.scripts
// @license       MIT License
// @run-at        document-start
// @require      file://j:\GOOGLE\ext_settings\scripts\SearchButtons\setMutationHandler.js
// @require      file://j:\GOOGLE\ext_settings\scripts\Shared\waitForKeyElements.js
// @require      file://j:\GOOGLE\ext_settings\scripts\Shared\jquery.min_1_7_2.js
// @require      file://j:\GOOGLE\ext_settings\scripts\SearchButtons\Search_Engines_buttons.user.js
//// @require       https://greasyfork.org/scripts/12228/code/setMutationHandler.js
//// @require       http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js
//// @require       https://gist.github.com/raw/2625891/waitForKeyElements.js
//// @grant         GM_addStyle
// ==/UserScript==
