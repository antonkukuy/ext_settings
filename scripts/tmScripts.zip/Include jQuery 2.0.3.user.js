// ==UserScript==
// @name        Include jQuery 2.0.3
// @namespace   includeJquery
// @include     *
// @version     0.1
// @grant       GM_registerMenuCommand
// ==/UserScript==

GM_registerMenuCommand('Подключить jQuery 2.0.3', includeJquery, 'j');

function includeJquery() {
    includeScriptOnPage('//ajax.googleapis.com/ajax/libs/jquery/2.0.3/jquery.min.js');
}

function includeScriptOnPage(url) {
    var head = document.getElementsByTagName('head')[0],
        script = document.createElement('script'),
        protocol = unsafeWindow.location.protocol;

    script.src= protocol + url;
    head.appendChild(script);
}