// ==UserScript==
// @name         Key buildings for input box(ESCAPE)
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @grant        none
// ==/UserScript==

window.addEventListener('keydown', function (e) {
    if (e.keyCode == 13)
      document.querySelector("input#cVim-command-bar-input").value = "open https://www.google.com/search?site=imghp&tbm=isch&source=hp&q=apple";
  }, true);