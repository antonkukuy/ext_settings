// ==UserScript==
// @name         Various things
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @require      http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js
//// @match        https://www.google.*/*         // don't work
// @include        https://www.google.*/search?*
// @include        http://www.google.*/search?*
//// @include        http://randomword.com/
//// @include        https://randomword.com/
//// @include        https://www.google.ru/search?q=translate+to+english*
//// @include        http://www.google.ru/search?q=translate+to+english*
//// @include        https://www.google.ru/search?q=translate+to+russian*
//// @include        http://www.google.ru/search?q=translate+to+russian*
// @run-at       document-end
// @grant        none
// ==/UserScript==

/*
setTimeout(function(){
    var bar = document.getElementById('hdtb');
if(bar){
    bar.style.position = "fixed";
}
    }, 1000);
*/

function main() {
     //alert('Hello World!');
    //chrome.extension.getBackgroundPage().console.log('foo');
    $('._LJ._qxg.xpdarr._WGh.vk_arc').click();
}
setTimeout(function(){
        $('div._LJ._qxg.xpdarr._WGh.vk_arc').click();
       // $('#random_word').dblclick();
//alert( "You have " + $("#random_word").size() + " elements" );
    }, 3000);
    //$('._LJ').click();
//alert( "You have " + $("div._LJ._qxg.xpdarr._WGh.vk_arc").size() + " elements" );
//var script = document.createElement('script');
//script.appendChild(document.createTextNode('('+ main +')();'));
//(document.body || document.head || document.documentElement).appendChild(script);