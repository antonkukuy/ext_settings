// ==UserScript==
// @name         Code with jQuery
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @grant        none
// @require      http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js
// @include      https://developer.chrome.com/*
// @include      http://developer.chrome.com/*
// ==/UserScript==

$('nav.inline-site-toc.no-permalink').css("display","none");
$('div[itemprop="articleBody"]').css("margin-left", "0px");

$(document).ready(function() {
    console.log("I'm running with jQuery!");
});