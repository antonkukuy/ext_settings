// ==UserScript==
// @name         jQuery
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://*/*
// @match        https://*/*
// @grant        none
// @require      http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js
// @include      http://*
// @include      https://*
// ==/UserScript==

$(document).ready(function() {
    console.log("I'm running with jQuery!");
});