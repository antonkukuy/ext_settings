// ==UserScript==
// @name           HabraGoogle
// @namespace      http://linux.ria.ua
// @description    Google Search for HabraHabr.ru
// @include        http://*habrahabr.ru/*
// @include        https://*habrahabr.ru/*
// @source         http://linux.ria.ua/habragoogle/
// @version        0.1
// ==/UserScript==

var hgButton = document.createElement('input');
hgButton.setAttribute('type', 'button');
hgButton.setAttribute('name', 'gsearch');
hgButton.setAttribute('value', 'HabraGoogle >');
hgButton.setAttribute('style', 'margin-right:12px');
hgButton.setAttribute('onClick', "document.location='http://www.google.ru/search?hl=ru&q=' + document.getElementById('search_field').value + '+site%3Ahabrahabr.ru'");

var hgContainer = document.getElementById('menu_tab').parentNode.parentNode;
hgContainer.appendChild(hgButton);