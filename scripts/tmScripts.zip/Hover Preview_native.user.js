// ==UserScript==
// @name           Hover Preview_native
// @namespace      HP
// @description    Pops up a floating div when you hover over a link, containing the target page!
// @version        0.1
// @require        file://j:\GOOGLE\ext_settings\scripts\Hover Preview.user.js
// @include        *
// @include        http://*
// @include        https://*
// @exclude        http://wikipedia.tld/*
// @exclude        http://*.wikipedia.tld/*
//// Since TLD doesn't work in Chrome:
// @exclude        http://wikipedia.org/*
// @exclude        http://*.wikipedia.org/*
//// https:
// @exclude        https://wikipedia.org/*
// @exclude        https://*.wikipedia.org/*
////
// @exclude        http://www.youtube.com/*
// @exclude        https://www.youtube.com/*
// @connect        *
// ==/UserScript==
