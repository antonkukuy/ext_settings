// ==UserScript==
// @name         EXAMPLES
// @namespace    christianvuerings
// @version      0.1
// @description  Load local JavaScript and CSS
// @author       Christian Vuerings
// @match        *://*/*
// @require      file:///Users/christian/Projects/sis-custom/dist/sis_cs.js
// @resource     sis_cs file:///Users/christian/Projects/sis-custom/dist/sis_cs.css
// @grant        GM_addStyle
// @grant        GM_getResourceText
// ==/UserScript==

var sis_cs = GM_getResourceText("sis_cs");
GM_addStyle(sis_cs);




// 1. Создаём новый объект XMLHttpRequest
var xhr = new XMLHttpRequest();

// 2. Конфигурируем его: GET-запрос на URL 'phones.json'
xhr.open('GET', 'phones.json', false);

// 3. Отсылаем запрос
xhr.send();

// 4. Если код ответа сервера не 200, то это ошибка
if (xhr.status != 200) {
  // обработать ошибку
  alert( xhr.status + ': ' + xhr.statusText ); // пример вывода: 404: Not Found
} else {
  // вывести результат
  alert( xhr.responseText ); // responseText -- текст ответа.
}